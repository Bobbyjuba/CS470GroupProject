﻿namespace CS470_GROUP_PROJECT {
	partial class Parking_Demo {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.LabelDashboard = new System.Windows.Forms.Label();
			this.LabelSubtitle = new System.Windows.Forms.Label();
			this.LabelUsername = new System.Windows.Forms.Label();
			this.LabelPassword = new System.Windows.Forms.Label();
			this.txtUsername = new System.Windows.Forms.TextBox();
			this.txtPassword = new System.Windows.Forms.TextBox();
			this.ButtonLogIn = new System.Windows.Forms.Button();
			this.buttonRegister = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// LabelDashboard
			// 
			this.LabelDashboard.AutoSize = true;
			this.LabelDashboard.Font = new System.Drawing.Font("Modern No. 20", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LabelDashboard.Location = new System.Drawing.Point(81, 24);
			this.LabelDashboard.Name = "LabelDashboard";
			this.LabelDashboard.Size = new System.Drawing.Size(552, 36);
			this.LabelDashboard.TabIndex = 0;
			this.LabelDashboard.Text = "Welcome to the Parking Lot Manager";
			// 
			// LabelSubtitle
			// 
			this.LabelSubtitle.AutoSize = true;
			this.LabelSubtitle.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LabelSubtitle.Location = new System.Drawing.Point(280, 83);
			this.LabelSubtitle.Name = "LabelSubtitle";
			this.LabelSubtitle.Size = new System.Drawing.Size(143, 15);
			this.LabelSubtitle.TabIndex = 1;
			this.LabelSubtitle.Text = "Please Log In or Register";
			// 
			// LabelUsername
			// 
			this.LabelUsername.AutoSize = true;
			this.LabelUsername.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LabelUsername.Location = new System.Drawing.Point(184, 127);
			this.LabelUsername.Name = "LabelUsername";
			this.LabelUsername.Size = new System.Drawing.Size(59, 15);
			this.LabelUsername.TabIndex = 2;
			this.LabelUsername.Text = "Username";
			// 
			// LabelPassword
			// 
			this.LabelPassword.AutoSize = true;
			this.LabelPassword.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LabelPassword.Location = new System.Drawing.Point(184, 163);
			this.LabelPassword.Name = "LabelPassword";
			this.LabelPassword.Size = new System.Drawing.Size(56, 15);
			this.LabelPassword.TabIndex = 3;
			this.LabelPassword.Text = "Password";
			// 
			// txtUsername
			// 
			this.txtUsername.Location = new System.Drawing.Point(283, 125);
			this.txtUsername.Name = "txtUsername";
			this.txtUsername.Size = new System.Drawing.Size(193, 20);
			this.txtUsername.TabIndex = 4;
			// 
			// txtPassword
			// 
			this.txtPassword.Location = new System.Drawing.Point(283, 163);
			this.txtPassword.Name = "txtPassword";
			this.txtPassword.Size = new System.Drawing.Size(193, 20);
			this.txtPassword.TabIndex = 5;
			// 
			// ButtonLogIn
			// 
			this.ButtonLogIn.Location = new System.Drawing.Point(230, 246);
			this.ButtonLogIn.Name = "ButtonLogIn";
			this.ButtonLogIn.Size = new System.Drawing.Size(75, 23);
			this.ButtonLogIn.TabIndex = 6;
			this.ButtonLogIn.Text = "Log In";
			this.ButtonLogIn.UseVisualStyleBackColor = true;
			// 
			// buttonRegister
			// 
			this.buttonRegister.Location = new System.Drawing.Point(348, 246);
			this.buttonRegister.Name = "buttonRegister";
			this.buttonRegister.Size = new System.Drawing.Size(75, 23);
			this.buttonRegister.TabIndex = 7;
			this.buttonRegister.Text = "Register";
			this.buttonRegister.UseVisualStyleBackColor = true;
			// 
			// Parking_Demo
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(692, 406);
			this.Controls.Add(this.buttonRegister);
			this.Controls.Add(this.ButtonLogIn);
			this.Controls.Add(this.txtPassword);
			this.Controls.Add(this.txtUsername);
			this.Controls.Add(this.LabelPassword);
			this.Controls.Add(this.LabelUsername);
			this.Controls.Add(this.LabelSubtitle);
			this.Controls.Add(this.LabelDashboard);
			this.Name = "Parking_Demo";
			this.Text = "Parking Demo";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label LabelDashboard;
		private System.Windows.Forms.Label LabelSubtitle;
		private System.Windows.Forms.Label LabelUsername;
		private System.Windows.Forms.Label LabelPassword;
		private System.Windows.Forms.TextBox txtUsername;
		private System.Windows.Forms.TextBox txtPassword;
		private System.Windows.Forms.Button ButtonLogIn;
		private System.Windows.Forms.Button buttonRegister;
	}
}

