﻿namespace CS470_GROUP_PROJECT {
	partial class SearchBox {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.TypeBox = new System.Windows.Forms.ListBox();
			this.FloorBox = new System.Windows.Forms.ListBox();
			this.LotBox = new System.Windows.Forms.ListBox();
			this.SpaceType = new System.Windows.Forms.Label();
			this.FloorNumber = new System.Windows.Forms.Label();
			this.LotLabel = new System.Windows.Forms.Label();
			this.LookForLabel = new System.Windows.Forms.Label();
			this.SpacesLabel = new System.Windows.Forms.Label();
			this.SearchButton = new System.Windows.Forms.Button();
			this.ParkingSpacesList = new System.Windows.Forms.ListBox();
			this.SuspendLayout();
			// 
			// TypeBox
			// 
			this.TypeBox.FormattingEnabled = true;
			this.TypeBox.Items.AddRange(new object[] {
            "Discounted",
            "Disabled",
            "Pass Required",
            "Typical"});
			this.TypeBox.Location = new System.Drawing.Point(223, 60);
			this.TypeBox.Name = "TypeBox";
			this.TypeBox.Size = new System.Drawing.Size(120, 43);
			this.TypeBox.TabIndex = 0;
			// 
			// FloorBox
			// 
			this.FloorBox.FormattingEnabled = true;
			this.FloorBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
			this.FloorBox.Location = new System.Drawing.Point(365, 60);
			this.FloorBox.Name = "FloorBox";
			this.FloorBox.Size = new System.Drawing.Size(38, 43);
			this.FloorBox.TabIndex = 1;
			// 
			// LotBox
			// 
			this.LotBox.FormattingEnabled = true;
			this.LotBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
			this.LotBox.Location = new System.Drawing.Point(429, 60);
			this.LotBox.Name = "LotBox";
			this.LotBox.Size = new System.Drawing.Size(39, 43);
			this.LotBox.TabIndex = 2;
			// 
			// SpaceType
			// 
			this.SpaceType.AutoSize = true;
			this.SpaceType.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.SpaceType.Location = new System.Drawing.Point(239, 32);
			this.SpaceType.Name = "SpaceType";
			this.SpaceType.Size = new System.Drawing.Size(80, 15);
			this.SpaceType.TabIndex = 3;
			this.SpaceType.Text = "Type of Space";
			// 
			// FloorNumber
			// 
			this.FloorNumber.AutoSize = true;
			this.FloorNumber.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.FloorNumber.Location = new System.Drawing.Point(362, 32);
			this.FloorNumber.Name = "FloorNumber";
			this.FloorNumber.Size = new System.Drawing.Size(36, 15);
			this.FloorNumber.TabIndex = 4;
			this.FloorNumber.Text = "Floor";
			// 
			// LotLabel
			// 
			this.LotLabel.AutoSize = true;
			this.LotLabel.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LotLabel.Location = new System.Drawing.Point(426, 32);
			this.LotLabel.Name = "LotLabel";
			this.LotLabel.Size = new System.Drawing.Size(26, 15);
			this.LotLabel.TabIndex = 5;
			this.LotLabel.Text = "Lot";
			// 
			// LookForLabel
			// 
			this.LookForLabel.AutoSize = true;
			this.LookForLabel.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LookForLabel.Location = new System.Drawing.Point(118, 71);
			this.LookForLabel.Name = "LookForLabel";
			this.LookForLabel.Size = new System.Drawing.Size(82, 18);
			this.LookForLabel.TabIndex = 7;
			this.LookForLabel.Text = "Look For:";
			// 
			// SpacesLabel
			// 
			this.SpacesLabel.AutoSize = true;
			this.SpacesLabel.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.SpacesLabel.Location = new System.Drawing.Point(62, 126);
			this.SpacesLabel.Name = "SpacesLabel";
			this.SpacesLabel.Size = new System.Drawing.Size(44, 15);
			this.SpacesLabel.TabIndex = 8;
			this.SpacesLabel.Text = "Spaces:";
			// 
			// SearchButton
			// 
			this.SearchButton.Location = new System.Drawing.Point(377, 116);
			this.SearchButton.Name = "SearchButton";
			this.SearchButton.Size = new System.Drawing.Size(75, 23);
			this.SearchButton.TabIndex = 9;
			this.SearchButton.Text = "Search";
			this.SearchButton.UseVisualStyleBackColor = true;
			this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
			// 
			// ParkingSpacesList
			// 
			this.ParkingSpacesList.FormattingEnabled = true;
			this.ParkingSpacesList.Location = new System.Drawing.Point(65, 145);
			this.ParkingSpacesList.Name = "ParkingSpacesList";
			this.ParkingSpacesList.Size = new System.Drawing.Size(403, 199);
			this.ParkingSpacesList.TabIndex = 10;
			// 
			// SearchBox
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.ParkingSpacesList);
			this.Controls.Add(this.SearchButton);
			this.Controls.Add(this.SpacesLabel);
			this.Controls.Add(this.LookForLabel);
			this.Controls.Add(this.LotLabel);
			this.Controls.Add(this.FloorNumber);
			this.Controls.Add(this.SpaceType);
			this.Controls.Add(this.LotBox);
			this.Controls.Add(this.FloorBox);
			this.Controls.Add(this.TypeBox);
			this.Name = "SearchBox";
			this.Text = "Search For Spaces";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ListBox TypeBox;
		private System.Windows.Forms.ListBox FloorBox;
		private System.Windows.Forms.ListBox LotBox;
		private System.Windows.Forms.Label SpaceType;
		private System.Windows.Forms.Label FloorNumber;
		private System.Windows.Forms.Label LotLabel;
		private System.Windows.Forms.Label LookForLabel;
		private System.Windows.Forms.Label SpacesLabel;
		private System.Windows.Forms.Button SearchButton;
		private System.Windows.Forms.ListBox ParkingSpacesList;
	}
}