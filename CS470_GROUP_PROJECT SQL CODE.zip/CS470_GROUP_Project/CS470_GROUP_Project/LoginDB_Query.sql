/*
	Run this code after creating a database named 'loginDB' and selecting that database
*/

CREATE TABLE LOGIN_TABLE (
	LOGIN_ID INT NOT NULL,
	USERNAME VARCHAR(50),
	PASSWORD VARCHAR(50),

	PRIMARY KEY (LOGIN_ID)
);