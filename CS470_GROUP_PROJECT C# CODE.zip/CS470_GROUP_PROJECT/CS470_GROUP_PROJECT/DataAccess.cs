﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data;

namespace CS470_GROUP_PROJECT {
	public class DataAccess { 
		public List<ParkingSpace> GetParkingSpaces(bool discounted, bool disabled, bool pass_required, int floor, int lot) {
			using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("CS470DB"))) {
				var output = connection.Query<ParkingSpace>($"SELECT * FROM PARKING_SPACE WHERE DISCOUNTED = '{discounted}' AND DISABLED = '{disabled}' " +
					$"AND REQUIRE_PASS = '{pass_required}' AND FLOOR = '{floor}' AND LOT = '{lot}'").ToList();
				return output;	
			}
		}
	}
}
