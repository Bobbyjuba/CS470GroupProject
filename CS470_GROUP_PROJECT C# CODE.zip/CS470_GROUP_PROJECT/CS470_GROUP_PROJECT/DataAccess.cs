﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data;
/*
 * Your queries for the database should go in the DataAccess Class
 */
namespace CS470_GROUP_PROJECT {
	public class DataAccess {
		// Query to get every parking space that the user has specified by floor, lot, and whether the space 
		// is discounted, disabled, requiring a pass, or is a typical space
		public List<ParkingSpace> GetParkingSpaces(bool discounted, bool disabled, bool pass_required, int floor, int lot) {
			using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("CS470DB"))) {
				var output = connection.Query<ParkingSpace>($"SELECT * FROM PARKING_SPACE WHERE DISCOUNTED = '{discounted}' AND DISABLED = '{disabled}' " +
					$"AND REQUIRE_PASS = '{pass_required}' AND FLOOR = '{floor}' AND LOT = '{lot}'").ToList();
				return output;
			}
		}

		// Query to get every available parking space, on any floor, across all lots
		public List<ParkingSpace> GetAnySpace() {
			using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("CS470DB"))) {
				var output = connection.Query<ParkingSpace>($"SELECT * FROM PARKING_SPACE WHERE AVAILABLE = 1").ToList();

				return output;
			}
		}

		// This function should give a parking space to the user who bought it
		public void BuyParkingSpace(int space_number, int floor, int lot) {
			using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("CS470DB"))) {
			}
		}

		public List<Customer> VerifyID(string username, string password) {
			using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("loginDB"))) {
				List<Customer> output = connection.Query<Customer>($"SELECT LOGIN_ID FROM LOGIN_TABLE WHERE USERNAME = '{username}' AND PASSWORD = '{password}'").ToList();

				return output;
			}
		}

		public void RegisterCustomer(string username, string password) {
			List<int> loginIDs = new List<int>();
			using (IDbConnection connection1 = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("loginDB"))) {
				List<string> output = connection1.Query<string>($"SELECT USERNAME FROM LOGIN_TABLE").ToList();
				int availableID = output.Count() + 1;

				if (output.Contains(username))
					return;

				else {
					using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("loginDB"))) {
						connection.Query($"INSERT INTO LOGIN_TABLE (LOGIN_ID, USERNAME, PASSWORD) VALUES ({availableID}, '{username}', '{password}');");
					}
				}
			}
		}
	}
}