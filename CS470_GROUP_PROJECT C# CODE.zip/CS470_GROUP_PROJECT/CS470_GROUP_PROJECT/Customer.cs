﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * This class will be used when the user purchases a parking space. The information will be 
 * filled in using queries and information provided in the SearchBox form
 */

namespace CS470_GROUP_PROJECT {
	public class Customer {
		public string first { get; set; }
		public string last { get; set; }
		public int customer_ID { get; set; }
		public string payment_method { get; set; }
		public int final_fee { get; set; }

		public int getCustomer_ID {
			get {
				return customer_ID;
			}
		}
	}
}
