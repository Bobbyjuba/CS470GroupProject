﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS470_GROUP_PROJECT {
	public class ParkingSpace {
		public int space_number { get; set; }
		public int floor { get; set; }
		public int lot { get; set; }
		public int cost { get; set; }
		public bool available { get; set; }
		public bool require_pass { get; set; }
		public bool disabled { get; set; }
		public bool discounted { get; set; }

		public string SpaceInfo {
			get {
				// Return the space number, the floor it is on, and the lot it is within
				return $"{ space_number } { floor } { lot }";
			}
		}

	}
}
