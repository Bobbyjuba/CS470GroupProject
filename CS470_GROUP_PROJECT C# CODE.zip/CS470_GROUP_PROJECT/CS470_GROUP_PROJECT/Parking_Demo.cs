﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS470_GROUP_PROJECT {
	public partial class Parking_Demo : Form {
		// db is a variabled to access all of our query functions in DataAccess; logins is used when verifying the user's login
		DataAccess db = new DataAccess();
		List<Customer> logins = new List<Customer>();

		public Parking_Demo() {
			InitializeComponent();
		}

		// This function will handle verifying the customer that is currently logging in to the application
		private void ButtonLogIn_Click(object sender, EventArgs e) {
			logins = db.VerifyID(txtUsername.Text, txtPassword.Text);

			// If logins.count is equal to one, the user was verified, so allow them to proceed
			if (logins.Count == 1) {
				MessageBox.Show("Login succesful");
				SearchBox startSearch = new SearchBox();
				this.Hide();
				startSearch.Show();
			}

			// If their credentials do not return an object from the database, display an error message
			else {
				MessageBox.Show("Invalid credentials");
			}
		}

		// This function will refister a new user when the register button is clicked
		private void buttonRegister_Click(object sender, EventArgs e) {
			// RegisterCustomer will attempt to add the user to the database
			db.RegisterCustomer(txtUsername.Text, txtPassword.Text);

			// VerifyID is being called here to check if the user was added
			logins = db.VerifyID(txtUsername.Text, txtPassword.Text);

			// If logins.count is equal to 1, the user was successfully added
			if (logins.Count == 1) {
				MessageBox.Show("Registration Successful");
				SearchBox startSearch = new SearchBox();
				this.Hide();
				startSearch.Show();
			}

			// If count is not equal to 1, that means the registration failed because the username was already taken
			else {
				MessageBox.Show("Username already taken");
			}
		}
	}
}