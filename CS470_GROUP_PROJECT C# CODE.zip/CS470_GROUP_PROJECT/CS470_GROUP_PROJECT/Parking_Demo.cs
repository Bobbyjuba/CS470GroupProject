﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS470_GROUP_PROJECT {
	public partial class Parking_Demo : Form {
		public Parking_Demo() {
			InitializeComponent();
		}
	}
}