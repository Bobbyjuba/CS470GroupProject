﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS470_GROUP_PROJECT {
	public static class Helper {
		// This function creates a connection to the database using the connection string found in App.config
		public static string CnnVal(string name) {
			return ConfigurationManager.ConnectionStrings[name].ConnectionString;
		}
	}
}
