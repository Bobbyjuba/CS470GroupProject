﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;

namespace CS470_GROUP_PROJECT {
	public partial class SearchBox : Form {
		// the booleans are used when querying for specific types of parking spaces; parkingSpaces is for storing available spaces; db is for accessing query functions
		bool discounted = false, disabled = false, pass_required = false;
		List<ParkingSpace> parkingSpaces = new List<ParkingSpace>();
		DataAccess db = new DataAccess();

		// Create a SearchBox object and add all the components of it
		public SearchBox() {
			InitializeComponent();
			UpdateBinding();
		}

		// This button should add a parking space for the customer who bought it
		// Should be added to the customer table and the space_assigned table
		private void PurchaseButton_Click(object sender, EventArgs e) {

		}

		// You can use this function to specify which query to use from the DataAccess class
		private void SearchButton_Click(object sender, EventArgs e) {
			// If the user wants to see discounted spaces, enable that variable
			if (TypeBox.Text == "Discounted")
				discounted = true;

			// If the user wsants to see disabled spaces, enable that variable
			else if (TypeBox.Text == "Disabled")
				disabled = true;
			
			// If the user wants to see spaces that require passes, enable that variable
			else if (TypeBox.Text == "Pass Required")
				pass_required = true;

			// If the user did not select anything, return all available spaces
			if (TypeBox.SelectedIndex == -1 && FloorBox.SelectedIndex == -1 && LotBox.SelectedIndex == -1) {
				parkingSpaces = db.GetAnySpace();
				UpdateBinding();
			}

			else {
				parkingSpaces = db.GetParkingSpaces(discounted, disabled, pass_required, Convert.ToInt32(FloorBox.Text), Convert.ToInt32(LotBox.Text));
				UpdateBinding();
			}
		}

		// This is function that simply updates the value for the Parking Spaces list box, so the information can be displayed
		// Call this function after every query or at least whenever you want current information displayed in the listbox
		private void UpdateBinding() {
			ParkingSpacesList.DataSource = parkingSpaces;
			ParkingSpacesList.DisplayMember = "SpaceInfo";
		}

	}
}