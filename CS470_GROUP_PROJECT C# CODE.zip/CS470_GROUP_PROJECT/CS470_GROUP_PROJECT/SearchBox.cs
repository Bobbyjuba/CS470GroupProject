﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;

namespace CS470_GROUP_PROJECT
{
	public partial class SearchBox : Form
	{
		bool discounted = false, disabled = false, pass_required = false;
		List<ParkingSpace> parkingSpaces = new List<ParkingSpace>();
		DataAccess db = new DataAccess();

		public SearchBox()
		{
			InitializeComponent();

			UpdateBinding();
		}

		private void SearchButton_Click(object sender, EventArgs e)
		{
			/*
				DataAccess db = new DataAccess();
				string mainconn = ConfigurationManager.ConnectionStrings["CS470DB"].ConnectionString;
				MySqlConnection mysqlconn = new MySqlConnection();
				string sqlquery = "";
				MySqlCommand sqlcomm = new MySqlCommand(sqlquery, mysqlconn);
				mysqlconn.Open();
				MySqlDataAdapter sdr = new MySqlDataAdapter(sqlcomm);
			*/

			if (TypeBox.Text == "Discounted")
				discounted = true;

			else if (TypeBox.Text == "Disabled")
				disabled = true;

			else if (TypeBox.Text == "Pass Required")
				pass_required = true;

			parkingSpaces = db.GetParkingSpaces(discounted, disabled, pass_required, Convert.ToInt32(FloorBox.Text), Convert.ToInt32(LotBox.Text));
			UpdateBinding();
		}

		private void UpdateBinding() {
			ParkingSpacesList.DataSource = parkingSpaces;
			ParkingSpacesList.DisplayMember = "SpaceInfo";
		}

	}
}