﻿namespace CS470_GROUP_PROJECT {
	partial class SearchBox {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.TypeBox = new System.Windows.Forms.ListBox();
			this.FloorBox = new System.Windows.Forms.ListBox();
			this.LotBox = new System.Windows.Forms.ListBox();
			this.SpaceType = new System.Windows.Forms.Label();
			this.FloorNumber = new System.Windows.Forms.Label();
			this.LotLabel = new System.Windows.Forms.Label();
			this.LookForLabel = new System.Windows.Forms.Label();
			this.SpaceNumberLabel = new System.Windows.Forms.Label();
			this.SearchButton = new System.Windows.Forms.Button();
			this.ParkingSpacesList = new System.Windows.Forms.ListBox();
			this.FloorNumberLabel = new System.Windows.Forms.Label();
			this.LotNumberLabel = new System.Windows.Forms.Label();
			this.CostLabel = new System.Windows.Forms.Label();
			this.txtSpaceNumber = new System.Windows.Forms.TextBox();
			this.txtFloorNumber = new System.Windows.Forms.TextBox();
			this.PaymentMethodBox = new System.Windows.Forms.ListBox();
			this.NumberBuyLabel = new System.Windows.Forms.Label();
			this.FloorBuyLabel = new System.Windows.Forms.Label();
			this.MethodBuyLabel = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.PurchaseButton = new System.Windows.Forms.Button();
			this.LotBuyLabel = new System.Windows.Forms.Label();
			this.txtLotNumber = new System.Windows.Forms.TextBox();
			this.FNameBuyLabel = new System.Windows.Forms.Label();
			this.LNameBuyLabel = new System.Windows.Forms.Label();
			this.txtFName = new System.Windows.Forms.TextBox();
			this.txtLName = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// TypeBox
			// 
			this.TypeBox.FormattingEnabled = true;
			this.TypeBox.Items.AddRange(new object[] {
            "Discounted",
            "Disabled",
            "Pass Required",
            "Typical"});
			this.TypeBox.Location = new System.Drawing.Point(223, 60);
			this.TypeBox.Name = "TypeBox";
			this.TypeBox.Size = new System.Drawing.Size(120, 43);
			this.TypeBox.TabIndex = 0;
			// 
			// FloorBox
			// 
			this.FloorBox.FormattingEnabled = true;
			this.FloorBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
			this.FloorBox.Location = new System.Drawing.Point(365, 60);
			this.FloorBox.Name = "FloorBox";
			this.FloorBox.Size = new System.Drawing.Size(38, 43);
			this.FloorBox.TabIndex = 1;
			// 
			// LotBox
			// 
			this.LotBox.FormattingEnabled = true;
			this.LotBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
			this.LotBox.Location = new System.Drawing.Point(429, 60);
			this.LotBox.Name = "LotBox";
			this.LotBox.Size = new System.Drawing.Size(39, 43);
			this.LotBox.TabIndex = 2;
			// 
			// SpaceType
			// 
			this.SpaceType.AutoSize = true;
			this.SpaceType.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.SpaceType.Location = new System.Drawing.Point(239, 32);
			this.SpaceType.Name = "SpaceType";
			this.SpaceType.Size = new System.Drawing.Size(80, 15);
			this.SpaceType.TabIndex = 3;
			this.SpaceType.Text = "Type of Space";
			// 
			// FloorNumber
			// 
			this.FloorNumber.AutoSize = true;
			this.FloorNumber.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.FloorNumber.Location = new System.Drawing.Point(362, 32);
			this.FloorNumber.Name = "FloorNumber";
			this.FloorNumber.Size = new System.Drawing.Size(36, 15);
			this.FloorNumber.TabIndex = 4;
			this.FloorNumber.Text = "Floor";
			// 
			// LotLabel
			// 
			this.LotLabel.AutoSize = true;
			this.LotLabel.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LotLabel.Location = new System.Drawing.Point(426, 32);
			this.LotLabel.Name = "LotLabel";
			this.LotLabel.Size = new System.Drawing.Size(26, 15);
			this.LotLabel.TabIndex = 5;
			this.LotLabel.Text = "Lot";
			// 
			// LookForLabel
			// 
			this.LookForLabel.AutoSize = true;
			this.LookForLabel.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LookForLabel.Location = new System.Drawing.Point(118, 71);
			this.LookForLabel.Name = "LookForLabel";
			this.LookForLabel.Size = new System.Drawing.Size(82, 18);
			this.LookForLabel.TabIndex = 7;
			this.LookForLabel.Text = "Look For:";
			// 
			// SpaceNumberLabel
			// 
			this.SpaceNumberLabel.AutoSize = true;
			this.SpaceNumberLabel.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.SpaceNumberLabel.Location = new System.Drawing.Point(62, 127);
			this.SpaceNumberLabel.Name = "SpaceNumberLabel";
			this.SpaceNumberLabel.Size = new System.Drawing.Size(94, 15);
			this.SpaceNumberLabel.TabIndex = 8;
			this.SpaceNumberLabel.Text = "Space Number";
			// 
			// SearchButton
			// 
			this.SearchButton.Location = new System.Drawing.Point(491, 66);
			this.SearchButton.Name = "SearchButton";
			this.SearchButton.Size = new System.Drawing.Size(75, 23);
			this.SearchButton.TabIndex = 9;
			this.SearchButton.Text = "Search";
			this.SearchButton.UseVisualStyleBackColor = true;
			this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
			// 
			// ParkingSpacesList
			// 
			this.ParkingSpacesList.FormattingEnabled = true;
			this.ParkingSpacesList.Location = new System.Drawing.Point(65, 145);
			this.ParkingSpacesList.Name = "ParkingSpacesList";
			this.ParkingSpacesList.Size = new System.Drawing.Size(403, 199);
			this.ParkingSpacesList.TabIndex = 10;
			// 
			// FloorNumberLabel
			// 
			this.FloorNumberLabel.AutoSize = true;
			this.FloorNumberLabel.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.FloorNumberLabel.Location = new System.Drawing.Point(194, 127);
			this.FloorNumberLabel.Name = "FloorNumberLabel";
			this.FloorNumberLabel.Size = new System.Drawing.Size(41, 15);
			this.FloorNumberLabel.TabIndex = 11;
			this.FloorNumberLabel.Text = "Floor";
			// 
			// LotNumberLabel
			// 
			this.LotNumberLabel.AutoSize = true;
			this.LotNumberLabel.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LotNumberLabel.Location = new System.Drawing.Point(290, 127);
			this.LotNumberLabel.Name = "LotNumberLabel";
			this.LotNumberLabel.Size = new System.Drawing.Size(29, 15);
			this.LotNumberLabel.TabIndex = 12;
			this.LotNumberLabel.Text = "Lot";
			// 
			// CostLabel
			// 
			this.CostLabel.AutoSize = true;
			this.CostLabel.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.CostLabel.Location = new System.Drawing.Point(399, 127);
			this.CostLabel.Name = "CostLabel";
			this.CostLabel.Size = new System.Drawing.Size(33, 15);
			this.CostLabel.TabIndex = 13;
			this.CostLabel.Text = "Cost";
			// 
			// txtSpaceNumber
			// 
			this.txtSpaceNumber.Location = new System.Drawing.Point(636, 244);
			this.txtSpaceNumber.Name = "txtSpaceNumber";
			this.txtSpaceNumber.Size = new System.Drawing.Size(129, 20);
			this.txtSpaceNumber.TabIndex = 14;
			// 
			// txtFloorNumber
			// 
			this.txtFloorNumber.Location = new System.Drawing.Point(636, 271);
			this.txtFloorNumber.Name = "txtFloorNumber";
			this.txtFloorNumber.Size = new System.Drawing.Size(129, 20);
			this.txtFloorNumber.TabIndex = 15;
			// 
			// PaymentMethodBox
			// 
			this.PaymentMethodBox.FormattingEnabled = true;
			this.PaymentMethodBox.Items.AddRange(new object[] {
            "Cash",
            "Parking Pass",
            "Disabled Parking Pass"});
			this.PaymentMethodBox.Location = new System.Drawing.Point(636, 329);
			this.PaymentMethodBox.Name = "PaymentMethodBox";
			this.PaymentMethodBox.Size = new System.Drawing.Size(129, 95);
			this.PaymentMethodBox.TabIndex = 16;
			// 
			// NumberBuyLabel
			// 
			this.NumberBuyLabel.AutoSize = true;
			this.NumberBuyLabel.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.NumberBuyLabel.Location = new System.Drawing.Point(504, 244);
			this.NumberBuyLabel.Name = "NumberBuyLabel";
			this.NumberBuyLabel.Size = new System.Drawing.Size(77, 15);
			this.NumberBuyLabel.TabIndex = 17;
			this.NumberBuyLabel.Text = "Space Number";
			// 
			// FloorBuyLabel
			// 
			this.FloorBuyLabel.AutoSize = true;
			this.FloorBuyLabel.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.FloorBuyLabel.Location = new System.Drawing.Point(504, 271);
			this.FloorBuyLabel.Name = "FloorBuyLabel";
			this.FloorBuyLabel.Size = new System.Drawing.Size(33, 15);
			this.FloorBuyLabel.TabIndex = 18;
			this.FloorBuyLabel.Text = "Floor";
			// 
			// MethodBuyLabel
			// 
			this.MethodBuyLabel.AutoSize = true;
			this.MethodBuyLabel.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.MethodBuyLabel.Location = new System.Drawing.Point(505, 329);
			this.MethodBuyLabel.Name = "MethodBuyLabel";
			this.MethodBuyLabel.Size = new System.Drawing.Size(90, 15);
			this.MethodBuyLabel.TabIndex = 19;
			this.MethodBuyLabel.Text = "Payment Method";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(504, 127);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(270, 15);
			this.label4.TabIndex = 20;
			this.label4.Text = "Which parking space would you like to purchase?";
			// 
			// PurchaseButton
			// 
			this.PurchaseButton.Location = new System.Drawing.Point(506, 401);
			this.PurchaseButton.Name = "PurchaseButton";
			this.PurchaseButton.Size = new System.Drawing.Size(75, 23);
			this.PurchaseButton.TabIndex = 21;
			this.PurchaseButton.Text = "Purchase";
			this.PurchaseButton.UseVisualStyleBackColor = true;
			this.PurchaseButton.Click += new System.EventHandler(this.PurchaseButton_Click);
			// 
			// LotBuyLabel
			// 
			this.LotBuyLabel.AutoSize = true;
			this.LotBuyLabel.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LotBuyLabel.Location = new System.Drawing.Point(505, 297);
			this.LotBuyLabel.Name = "LotBuyLabel";
			this.LotBuyLabel.Size = new System.Drawing.Size(24, 15);
			this.LotBuyLabel.TabIndex = 22;
			this.LotBuyLabel.Text = "Lot";
			// 
			// txtLotNumber
			// 
			this.txtLotNumber.Location = new System.Drawing.Point(636, 297);
			this.txtLotNumber.Name = "txtLotNumber";
			this.txtLotNumber.Size = new System.Drawing.Size(129, 20);
			this.txtLotNumber.TabIndex = 23;
			// 
			// FNameBuyLabel
			// 
			this.FNameBuyLabel.AutoSize = true;
			this.FNameBuyLabel.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.FNameBuyLabel.Location = new System.Drawing.Point(507, 158);
			this.FNameBuyLabel.Name = "FNameBuyLabel";
			this.FNameBuyLabel.Size = new System.Drawing.Size(62, 15);
			this.FNameBuyLabel.TabIndex = 24;
			this.FNameBuyLabel.Text = "First Name";
			// 
			// LNameBuyLabel
			// 
			this.LNameBuyLabel.AutoSize = true;
			this.LNameBuyLabel.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LNameBuyLabel.Location = new System.Drawing.Point(507, 189);
			this.LNameBuyLabel.Name = "LNameBuyLabel";
			this.LNameBuyLabel.Size = new System.Drawing.Size(60, 15);
			this.LNameBuyLabel.TabIndex = 25;
			this.LNameBuyLabel.Text = "Last Name";
			// 
			// txtFName
			// 
			this.txtFName.Location = new System.Drawing.Point(636, 158);
			this.txtFName.Name = "txtFName";
			this.txtFName.Size = new System.Drawing.Size(129, 20);
			this.txtFName.TabIndex = 26;
			// 
			// txtLName
			// 
			this.txtLName.Location = new System.Drawing.Point(636, 189);
			this.txtLName.Name = "txtLName";
			this.txtLName.Size = new System.Drawing.Size(129, 20);
			this.txtLName.TabIndex = 27;
			// 
			// SearchBox
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.txtLName);
			this.Controls.Add(this.txtFName);
			this.Controls.Add(this.LNameBuyLabel);
			this.Controls.Add(this.FNameBuyLabel);
			this.Controls.Add(this.txtLotNumber);
			this.Controls.Add(this.LotBuyLabel);
			this.Controls.Add(this.PurchaseButton);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.MethodBuyLabel);
			this.Controls.Add(this.FloorBuyLabel);
			this.Controls.Add(this.NumberBuyLabel);
			this.Controls.Add(this.PaymentMethodBox);
			this.Controls.Add(this.txtFloorNumber);
			this.Controls.Add(this.txtSpaceNumber);
			this.Controls.Add(this.CostLabel);
			this.Controls.Add(this.LotNumberLabel);
			this.Controls.Add(this.FloorNumberLabel);
			this.Controls.Add(this.ParkingSpacesList);
			this.Controls.Add(this.SearchButton);
			this.Controls.Add(this.SpaceNumberLabel);
			this.Controls.Add(this.LookForLabel);
			this.Controls.Add(this.LotLabel);
			this.Controls.Add(this.FloorNumber);
			this.Controls.Add(this.SpaceType);
			this.Controls.Add(this.LotBox);
			this.Controls.Add(this.FloorBox);
			this.Controls.Add(this.TypeBox);
			this.Name = "SearchBox";
			this.Text = "Search For Spaces";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ListBox TypeBox;
		private System.Windows.Forms.ListBox FloorBox;
		private System.Windows.Forms.ListBox LotBox;
		private System.Windows.Forms.Label SpaceType;
		private System.Windows.Forms.Label FloorNumber;
		private System.Windows.Forms.Label LotLabel;
		private System.Windows.Forms.Label LookForLabel;
		private System.Windows.Forms.Label SpaceNumberLabel;
		private System.Windows.Forms.Button SearchButton;
		private System.Windows.Forms.ListBox ParkingSpacesList;
		private System.Windows.Forms.Label FloorNumberLabel;
		private System.Windows.Forms.Label LotNumberLabel;
		private System.Windows.Forms.Label CostLabel;
		private System.Windows.Forms.TextBox txtSpaceNumber;
		private System.Windows.Forms.TextBox txtFloorNumber;
		private System.Windows.Forms.ListBox PaymentMethodBox;
		private System.Windows.Forms.Label NumberBuyLabel;
		private System.Windows.Forms.Label FloorBuyLabel;
		private System.Windows.Forms.Label MethodBuyLabel;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button PurchaseButton;
		private System.Windows.Forms.Label LotBuyLabel;
		private System.Windows.Forms.TextBox txtLotNumber;
		private System.Windows.Forms.Label FNameBuyLabel;
		private System.Windows.Forms.Label LNameBuyLabel;
		private System.Windows.Forms.TextBox txtFName;
		private System.Windows.Forms.TextBox txtLName;
	}
}